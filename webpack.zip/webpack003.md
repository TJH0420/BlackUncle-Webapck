## 库打包
```
module.exports = {
	mode: 'production',
	entry: './src/index.js',
	externals: 'lodash', // 忽略这些库
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: 'library.js',
		library: 'root', // 模块名称
		libraryTarget: 'umd' // 输出格式 也可以绑定this/global等
	}
}
```
## PWA 的打包配置
### 安装
```
cnpm install -D workbox-webpack-plugin
```
![](https://user-gold-cdn.xitu.io/2020/4/19/17191d7465ffb23f)

![](https://user-gold-cdn.xitu.io/2020/4/19/17191d778f0a667b?w=446&h=284&f=png&s=118764)

![](https://user-gold-cdn.xitu.io/2020/4/19/17191d8362600aaa?w=1008&h=367&f=png&s=42952)
## 起一个服务
### 安装
```
cnpm i http-server -D
```
### JSON文件中
```
"scripts": {
  "server": "http-server dist",
},
```
## TypeScript 的打包配置
### 在node开发中使用npm init会生成一个pakeage.json文件
npm install ts-loader typescript --save-dev
```
const path = require('path');
module.exports = {
    mode: 'production',
    entry: {
        main: './src/index.ts'
    },
    module: {
        rules: [{
            test: /\.ts?$/,
            use: 'ts-loader', // 借助ts-loader依赖进行打包
            exclude: /node_modules/ // 除node_modules文件夹下之外的以.ts结尾的文件
        }]
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, 'dist')
    }
}
```
### 根目录下建一个文件 tsconfig.json
```
{
    "compilerOptions": {
        "outDir": "./dist",  // 当用ts-loader做ts打包的时候，把打包生成的文件会放到dist目录下，这个不写也行，因为在webpack.config.js里已经配置过了output
        "module": "es6",   // 在index.tsx代码里，我们用ES6这种模块引入方式
        "target": "ES5",  // 打包ts语法的时候，最终转换成ES5的代码，方便大部分浏览器运行
        "allowJs": true  // 运行引入JS文件
    }
}
```
### 库也支持ts的话，要安装库的类型文件
npm install @types/xxx --save-dev

## 使用 Webpack DevServer 实现请求转发
## WebpackDevServer 解决单页面应用路由问题
```
devServer: {
    port: 8082,
    open: true,
    compress: true,
    historyApiFallback:true,
    proxy: {
        '/api': {
            target: 'http://localhost: 3002',
            changeOrigin: true, 
            pathRewrite: {
                '^/api': '/api'
            },
            changeOrigin:true
        }
    }
}
```
## Eslint
npm i -D eslint
新建一个配置文件.eslintrc.js
```
文件里面内容是规则
```

```
rules: [
  {
    test: /\.(vue|js|jsx)$/,
    loader: 'eslint-loader',
    exclude: /node_modules/,
    enforce: 'pre'
  },
]
```
    