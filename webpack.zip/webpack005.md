## 如何编写一个 Loader
- 新建一个loaders目录
- 目录下新建一个replaceLoader.js文件
```
const loaderUtils = require('loader-utils');
module.exports = function(source) {
	return source.replace('blue', 'black');
}
```
- 目录下新建一个replaceLoaderAsync.js文件
```
const loaderUtils = require('loader-utils');
module.exports = function(source) {
	const options = loaderUtils.getOptions(this);
	const callback = this.async();
	setTimeout(() => {
		const result = source.replace('dalao', options.name);
		callback(null, result);
	}, 1000);
}
```
- webpack.config.js的配置文件
```
const path = require('path');
module.exports = {
	mode: 'development',
	entry: {
		main: './src/index.js'
	},
	resolveLoader: {
		modules: ['node_modules', './loaders']
	},
	module: {
		rules: [{
			test: /\.js/,
			use: [
				// {
				// 	loader: 'replaceLoader',
				// },
				// {
				// 	loader: 'replaceLoaderAsync',
				// 	options: {
				// 		name: 'uncle'
				// 	}
				// },
				{
					loader: path.resolve(__dirname, './loaders/replaceLoader.js')
				},
				{
					loader: path.resolve(__dirname, './loaders/replaceLoaderAsync.js'),
					options: {
						name: 'uncle'
					}
				}
			]
		}]
	},
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: '[name].js'
	}
}
```

## 如何编写一个 plugins
- 新建一个plugins目录
- 目录下新建一个copyright-webpack-plugin.js文件
```
class CopyrightWebpackPlugin {
	apply(compiler) {
		compiler.hooks.compile.tap('CopyrightWebpackPlugin', (compilation) => {
			console.log('compiler');
		})
		compiler.hooks.emit.tapAsync('CopyrightWebpackPlugin', (compilation, cb) => {
			debugger;
			compilation.assets['copyright.txt'] = {
				source: function () {
					return 'copyright by black uncle'
				},
				size: function () {
					return 24;
				}
			};
			cb();
		})
	}
}
module.exports = CopyrightWebpackPlugin;
```
- webpack.config.js的配置文件
```
const path = require('path');
const CopyRightWebpackPlugin = require('./plugins/copyright-webpack-plugin');

module.exports = {
	mode: 'development',
	entry: {
		main: './src/index.js'
	},
	plugins: [
		new CopyRightWebpackPlugin()
	],
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: '[name].js'
	}
}
```