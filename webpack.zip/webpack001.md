## 概念
本质上，webpack 是一个现代 JavaScript 应用程序的静态模块打包器(module bundler)。当 webpack 处理应用程序时，它会递归地构建一个依赖关系图(dependency graph)，其中包含应用程序需要的每个模块，然后将所有这些模块打包成一个或多个 bundle。
## 四个核心概念
- 入口(entry)
- 输出(output)
- loader
- 插件(plugins)

## webpack的安装
### 全局安装
```
cnpm uninstall webpack webpack-cli -g
```
### 局部安装
```
cnpm install webpack webpack-cli -D
```
### npx运行
```
npx webpack -v
```
### webpack的信息
```
npm info webpack
```
### webpack的信息
#### 新建一个webpack.config.js文件
```
const path = require('path')
module.exports = {
    entry: './index.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist')
    }
}
```
#### 运行
```
webpack
或
npx webpack  执行的默认文件为webpack.config.js
```

#### 设置指定的js文件
```
npx webpack --config 
```

#### 设置命令 即可用 npm run build
```
"scripts": {
    "build":"webpack"
},
```
#### mode
development 打包后不会压缩
production 打包后会压缩

## module
### rules
#### url-loader

url-loader和file-loader的区别：url-loader的图片转base64

```
rules: [{
	test: /\.(jpg|png|gif)$/,
			use: {
		loader: 'url-loader',
		options: {
			name: '[name]_[hash].[ext]',
			outputPath: 'images/',
			limit: 10240
		}
	} 
}, {
	test: /\.(eot|ttf|svg)$/,
	use: {
		loader: 'file-loader'
	} 
}, {
	test: /\.scss$/,
	use: [
		'style-loader', 
		{
			loader: 'css-loader',
			options: {
				importLoaders: 2
			}
		},
		'sass-loader',
		'postcss-loader'
	]
}, {
	test: /\.css$/,
	use: [
		'style-loader',
		'css-loader',
		'postcss-loader'
	]
}]
```

#### bable
```
npm i babel-loader -D
npm i @babel/core -D
npm i @babel/preset-env -D
npm i babel-polifill --save

rules:[   
	{
		test: /\.js$/,   //匹配JS文件  
		use: 'babel-loader',
		exclude: /node_modules/,   //排除node_modules目录
		option: {
			presets: [
				[
					'@babel/preset-env',
					{
						'targets': {
							chrome: '67'
						},
						"useBuiltIns": "usage"
					}
				]
			]
		}
	} 
]
```

![](https://user-gold-cdn.xitu.io/2020/4/17/17183ff7d507baff?w=809&h=324&f=png&s=38044)

#### postcss-loader新建文件如图
![](https://user-gold-cdn.xitu.io/2020/4/15/1717b628821fd4c2?w=633&h=272&f=png&s=25037)

## plugins
### html-webpack-plugin
### CleanWebpackPlugin
### HotModuleReplacementPlugin
```
plugins: [
	new HtmlWebpackPlugin({
		template: 'src/index.html'
	}), 
	new CleanWebpackPlugin(['dist']),
	new webpack.HotModuleReplacementPlugin()
],
```
## output
```
output: {
	publicPath:'./',
	filename: '[name].js',
	path: path.resolve(__dirname, 'dist')
}
```

## devtool

### sourceMap
```
devtool: 'cheap-module-eval-source-map',
```

## devServer
```
"scripts": {
    "dev-build": "webpack --config ./build/webpack.common.js",
    "dev": "webpack-dev-server --config ./build/webpack.common.js",
    "build": "webpack --env.production --config ./build/webpack.common.js"
},
```

```
devServer: {
	contentBase: './dist',
	open: true,
	port: 8080,
	hot: true,
	hotOnly: true
},
```
