## tree shaking
- 只支持ES Module
```
optimization: {
	runtimeChunk: {
		name: 'runtime'
	},
	usedExports: true,
	splitChunks: {
		chunks: 'all',
		cacheGroups: {
			vendors: {
				test: /[\\/]node_modules[\\/]/,
				priority: -10,
				name: 'vendors',
			}
		}
	}
}
```
- JSON文件里面：false或者数组指定不处理的
```
sideEffects: false 
```

## Develoment 和 Production 模式的区分打包
### JSON文件夹 

```
"scripts": {
    "dev": "webpack-dev-server --config ./build/webpack.dev.js",
    "build": "webpack --config ./build/webpack.prod.js",
},
```

### 把公共的提取出来放入common.js里面
#### webpack.dev.js添加如下代码

```
const merge = require('webpack-merge');
const commonConfig = require('./webpack.common.js');
module.exports = merge(commonConfig, devConfig); 
```

## SplitChunksPlugin 
```
optimization: {
	splitChunks: {
		chunks: "all",          //async异步代码分割 initial同步代码分割 all同步异步分割都开启
		minSize: 30000,         //字节 引入的文件大于30kb才进行分割
		//maxSize: 50000,       //50kb，尝试将大于50kb的文件拆分成n个50kb的文件
		minChunks: 1,           //模块至少使用次数
		maxAsyncRequests: 5,    //同时加载的模块数量最多是5个，只分割出同时引入的前5个文件
		maxInitialRequests: 3,  //首页加载的时候引入的文件最多3个
		automaticNameDelimiter: '~', //缓存组和生成文件名称之间的连接符
		name: true,                  //缓存组里面的filename生效，覆盖默认命名
		cacheGroups: { //缓存组，将所有加载模块放在缓存里面一起分割打包
			vendors: {  //自定义打包模块
				test: /[\\/]node_modules[\\/]/,
				priority: -10, //优先级，先打包到哪个组里面，值越大，优先级越高
				filename: 'vendors.js',
            },
			default: { //默认打包模块
				priority: -20,
				reuseExistingChunk: true, //模块嵌套引入时，判断是否复用已经被打包的模块
				filename: 'common.js'
			}
		}
	}
}
```
### Lazy loading 即import()这种写法
### chunks

## 打包分析（即analysis工具）
## Preloading 
```
document.addEventListener('click',()=>{
    import(/* webpackPreload: true */'./util/click').then(({default:func}) =>{
        func();
    })
})
```
## Prefetching 空闲时间加载

## CSS文件代码分割和压缩
```
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");
const prodConfig = {
	module: {
		rules:[{
			test: /\.scss$/,
			use: [
				MiniCssExtractPlugin.loader, 
				{
					loader: 'css-loader',
					options: {
						importLoaders: 2
					}
				},
				'sass-loader',
				'postcss-loader'
			]
		}, {
			test: /\.css$/,
			use: [
				MiniCssExtractPlugin.loader,
				'css-loader',
				'postcss-loader'
			]
		}]
	},
	optimization: {
		minimizer: [new OptimizeCSSAssetsPlugin({})]
	},
	plugins: [
		new MiniCssExtractPlugin({
			filename: '[name].css',
			chunkFilename: '[name].chunk.css'
		})
	],
}
```

- JSON文件里面：false修改为数组，里面是不处理的文件
```
sideEffects: ["*.css"] 
```

## hash解决浏览器cache
```
output: {
  filename: '[name].[contenthash].js',
  chunkFilename: '[name].[contenthash].js'
}
```

## Shimming 的作用
```
const webpack = require('webpack');

plugins: [
  new HtmlWebpackPlugin({
      template: 'src/index.html'
  }), 
  new CleanWebpackPlugin(),
  new webpack.ProvidePlugin({
      $: 'jquery',
      _join: ['lodash', 'join']
      //如果一个模块中使用了$字符串,就会在模块中自动得引用jquery
  })
]
```
## 让this===window true
```
rules: [
  {
      test: require.resolve("some-module"),
      use: "imports-loader?this=>window"
  }
]
```
