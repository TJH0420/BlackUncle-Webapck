## webpack性能优化
###  更新node，npm版本
###  exclude/include的使用
#### 基本大部分的node_modules都压缩过的，不要再次打包 
```
rules:[   
	{
		test: /\.js$/,   //匹配JS文件  
		use: 'babel-loader',
		exclude: /node_modules/,   //排除node_modules目录
	} 
]
```
###  不同环境使用合理的插件Plugin（选社区认可的Plugin）
#### dev环境不压缩 OptimizeCSSAssetsPlugin
###  resolve的合理配置  而资源类写后缀（如图片）
```
resolve: {
    extensions: ['.js', '.vue', '.json'],
    mainFiles:[
        'index','main'
    ],// 当只引入文件夹，默认寻找（其实这个配置影响打包性能）
    alias: {
        'vue$': 'vue/dist/vue.esm.js',
        '@': resolve('src'),
    }
},
```
###  DllPlugin
- 新建一个webpack.dll.js文件
```
const path = require('path');
const webpack = require('webpack');

module.exports = {
	mode: 'production',
	entry: {
		vendors: ['lodash'],
		react: ['react', 'react-dom'],
		jquery: ['jquery']
	},
	output: {
		filename: '[name].dll.js',
		path: path.resolve(__dirname, '../dll'),
		library: '[name]'
	},
	plugins: [
		new webpack.DllPlugin({
			name: '[name]',
			path: path.resolve(__dirname, '../dll/[name].manifest.json'),
		})
	]
}
```
- 新建一个webpack.common.js文件
npm i add-asset-html-webpack-plugin -D
```
const AddAssetHtmlWebpackPlugin = require('add-asset-html-webpack-plugin');
plugins: [
	new HtmlWebpackPlugin(),
	new webpack.DllReferencePlugin({
		context:path.join(__dirname),
		manifest:require('./build/vendor-manifest.json'),
	}),
	new AddAssetHtmlPlugin({ filepath:path.resolve(__dirname, './build/*.dll.js'), }),
],
```
- 批量处理
```
const path = require('path');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const AddAssetHtmlWebpackPlugin = require('add-asset-html-webpack-plugin');
const webpack = require('webpack');


const makePlugins = (configs) => {
	const files = fs.readdirSync(path.resolve(__dirname, '../dll'));
	files.forEach(file => {
		if (/.*\.dll.js/.test(file)) {
			plugins.push(new AddAssetHtmlWebpackPlugin({
				filepath: path.resolve(__dirname, '../dll', file)
			}))
		}
		if (/.*\.manifest.json/.test(file)) {
			plugins.push(new webpack.DllReferencePlugin({
				manifest: path.resolve(__dirname, '../dll', file)
			}))
		}
	});
	return plugins;
}

const configs = {
	entry: {
		index: './src/index.js',
		list: './src/list.js',
		detail: './src/detail.js',
	},
	resolve: {
		extensions: ['.js', '.jsx'],
	},
	module: {
		rules: [{
			test: /\.jsx?$/,
			include: path.resolve(__dirname, '../src'),
			use: [{
				loader: 'babel-loader'
			}]
		}, {
			test: /\.(jpg|png|gif)$/,
			use: {
				loader: 'url-loader',
				options: {
					name: '[name]_[hash].[ext]',
					outputPath: 'images/',
					limit: 10240
				}
			}
		}, {
			test: /\.(eot|ttf|svg)$/,
			use: {
				loader: 'file-loader'
			}
		}]
	},
	optimization: {
		runtimeChunk: {
			name: 'runtime'
		},
		usedExports: true,
		splitChunks: {
			chunks: 'all',
			cacheGroups: {
				vendors: {
					test: /[\\/]node_modules[\\/]/,
					priority: -10,
					name: 'vendors',
				}
			}
		}
	},
	performance: false,
	output: {
		path: path.resolve(__dirname, '../dist')
	}
}

configs.plugins = makePlugins(configs);

module.exports = configs
```
### tree shaking
### thread-loader 多进程打包
### parallel-webpack 多进程打包
### happypack 多进程打包
### 结合stats分析打包结果

## 多页面打包配置
```
const plugins = [
    new CleanWebpackPlugin(['dist'], {
        root: path.resolve(__dirname, '../')
    })
];
Object.keys(configs.entry).forEach(item => {
    plugins.push(
        new HtmlWebpackPlugin({
            template: 'src/index.html',
            filename: `${item}.html`,
            chunks: ['runtime', 'vendors', item]
        })
    )
});
```



